package com.creacionesyazmin.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout content;

    int pink = Color.rgb(194, 24, 91);
    int lightPink = Color.rgb(255, 247, 250);

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(pink);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(16, 18, 16, 18);
        return t;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    void base(String heading) {
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(lightPink);

        TextView h = title(heading, 24);
        main.addView(h, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18, 8, 18, 24);
        scroll.addView(content);
        main.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(main);
    }

    void showHome() {
        base("CREACIONES YAZMIN");

        TextView welcome = title("Detalles que inspiran", 18);
        content.addView(welcome);

        Button create = button("✨ Generar tu moño");
        create.setOnClickListener(v -> showCreateBow());
        content.addView(create);

        String[] cats = {
            "🎀 Moños", "👑 Diademas", "💀 Diademas de Catrina",
            "🎄 Diademas Navideñas", "🇲🇽 Diademas de 15 de Septiembre",
            "🎒 Moños escolares", "✨ Personalizados",
            "🌸 Listón personalizado", "🤰 Cinturones de maternidad"
        };

        TextView catTitle = title("Categorías", 20);
        content.addView(catTitle);
        for (String c : cats) {
            Button b = button(c);
            b.setOnClickListener(v -> showCatalog(c));
            content.addView(b);
        }

        Button orders = button("📦 Mis pedidos");
        orders.setOnClickListener(v -> showOrders());
        content.addView(orders);

        Button account = button("👤 Mi cuenta");
        account.setOnClickListener(v -> showAccount());
        content.addView(account);
    }

    void showCatalog(String category) {
        base(category);
        TextView info = title("Productos de " + category, 20);
        content.addView(info);

        TextView empty = new TextView(this);
        empty.setText("Aquí aparecerán los productos cuando los conectemos con Firebase.");
        empty.setTextSize(16);
        empty.setPadding(12, 20, 12, 20);
        content.addView(empty);

        Button back = button("← Volver");
        back.setOnClickListener(v -> showHome());
        content.addView(back);
    }

    void showCreateBow() {
        base("✨ Generar tu moño");

        EditText name = new EditText(this);
        name.setHint("Nombre que llevará el moño");
        content.addView(name);

        String[] options = {"Tipo de moño", "Color", "Estilo", "Decoración"};
        for (String o : options) {
            Spinner s = new Spinner(this);
            String[] values = {o, "Opción 1", "Opción 2", "Opción 3"};
            s.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, values));
            content.addView(s);
        }

        Button generate = button("✨ GENERAR MOÑO");
        generate.setOnClickListener(v -> {
            TextView preview = title("👀 Vista previa del diseño", 20);
            content.addView(preview);
            TextView status = new TextView(this);
            status.setText("Este diseño es una propuesta. Al solicitarlo quedará 🟡 EN PROCESO para revisión.");
            status.setTextSize(16);
            status.setPadding(12, 12, 12, 12);
            content.addView(status);
            Button request = button("🎀 SOLICITAR ESTE MOÑO");
            request.setOnClickListener(x -> Toast.makeText(this, "Pedido personalizado: EN PROCESO", Toast.LENGTH_LONG).show());
            content.addView(request);
        });
        content.addView(generate);

        Button back = button("← Volver");
        back.setOnClickListener(v -> showHome());
        content.addView(back);
    }

    void showOrders() {
        base("📦 Mis pedidos");
        TextView t = new TextView(this);
        t.setText("Aquí aparecerán tus pedidos y estados: 🟡 En proceso · 🟢 Preparando · 🔵 Enviado · 🟣 Entregado · 🔴 Rechazado.");
        t.setTextSize(16);
        t.setPadding(12, 20, 12, 20);
        content.addView(t);
        Button back = button("← Inicio");
        back.setOnClickListener(v -> showHome());
        content.addView(back);
    }

    void showAccount() {
        base("👤 Mi cuenta");
        String[] items = {"📦 Mis pedidos", "🎀 Mis moños personalizados", "📍 Mis direcciones", "💳 Mis métodos de pago", "🔔 Notificaciones"};
        for (String item : items) content.addView(button(item));
        Button back = button("← Inicio");
        back.setOnClickListener(v -> showHome());
        content.addView(back);
    }
}
