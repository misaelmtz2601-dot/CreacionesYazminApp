package com.creacionesyazmin.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int pink = Color.rgb(185,130,199), dark = Color.rgb(92,65,96), bg = Color.rgb(255,249,253), lilac = Color.rgb(242,229,247), soft = Color.rgb(255,238,247);
    String[] productNames = {"Moño personalizado", "Diadema de Catrina", "Diadema de temporada", "Moño especial", "Moño infantil", "Moño escolar", "Diseño personalizado", "Moño rosa", "Moño elegante", "Nuevo diseño"};
    int[] productImages = {R.drawable.img_1000128501, R.drawable.img_1000128503, R.drawable.img_1000128505, R.drawable.img_1000128495, R.drawable.img_1000128491, R.drawable.img_1000128497, R.drawable.img_1000128499, R.drawable.img_1000128493, R.drawable.img_1000128482, R.drawable.img_1000128489};

    @Override public void onCreate(Bundle b) { super.onCreate(b); showHome(); }

    GradientDrawable rounded(int color, int radius) { GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    TextView text(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setPadding(8,6,8,6); return t; }
    TextView center(String s,float size,int color,boolean bold){ TextView t=text(s,size,color,bold); t.setGravity(Gravity.CENTER); return t; }
    LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(dark); b.setBackground(rounded(Color.WHITE,28)); return b; }

    void base(){
        root=col(); root.setBackgroundColor(bg); setContentView(root);
        LinearLayout top=row(); top.setPadding(12,10,12,4);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo_creaciones_yazmin); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        top.addView(logo,new LinearLayout.LayoutParams(0,70,1));
        Button cart=btn("🛒"); cart.setTextSize(20); top.addView(cart,new LinearLayout.LayoutParams(58,58));
        root.addView(top);
        content=col(); ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row(); nav.setPadding(8,4,8,8); String[] n={"⌂\nInicio","▦\nCatálogo","✨\nCrear","📦\nPedidos","♡\nCuenta"};
        for(String x:n){ Button b=btn(x); b.setTextSize(12); nav.addView(b,new LinearLayout.LayoutParams(0,62,1)); if(x.contains("Inicio"))b.setOnClickListener(v->showHome()); if(x.contains("Catálogo"))b.setOnClickListener(v->showCatalog("Catálogo")); if(x.contains("Crear"))b.setOnClickListener(v->showCreateBow()); if(x.contains("Pedidos"))b.setOnClickListener(v->showOrders()); if(x.contains("Cuenta"))b.setOnClickListener(v->showAccount()); }
        root.addView(nav);
    }

    void showHome(){
        base();
        EditText search=new EditText(this); search.setHint("¿Qué estás buscando?"); search.setSingleLine(); search.setBackground(rounded(Color.WHITE,35)); search.setPadding(20,0,20,0); content.addView(search,new LinearLayout.LayoutParams(-1,52));
        TextView hero=center("Pequeños detalles, grandes sonrisas\n🎀  MOÑOS PERSONALIZADOS",19,dark,true); hero.setBackground(rounded(lilac,32)); hero.setPadding(15,22,15,22); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,150); hp.setMargins(0,14,0,10); content.addView(hero,hp);
        TextView season=center("✨ Novedades y temporadas\nMoños nuevos  •  Listón sublimado  •  Colecciones de temporada",14,pink,true); season.setBackground(rounded(soft,28)); season.setPadding(12,14,12,14); content.addView(season);
        TextView ct=text("Categorías",21,dark,true); ct.setPadding(6,18,6,6); content.addView(ct);
        String[] cats={"🎀 Moños","👑 Diademas","💀 Catrina","🎄 Navidad","🇲🇽 15 de Septiembre","🎒 Escolares","✨ Personalizados","🌸 Listón sublimado"};
        LinearLayout cr=row(); cr.setGravity(Gravity.CENTER); for(String c:cats){ Button b=btn(c); b.setTextSize(12); b.setBackground(rounded(Color.WHITE,24)); b.setOnClickListener(v->showCatalog(c)); cr.addView(b,new LinearLayout.LayoutParams(150,58)); } ScrollView h=new ScrollView(this); h.setHorizontalScrollBarEnabled(false); h.addView(cr); content.addView(h,new LinearLayout.LayoutParams(-1,68));
        TextView ft=text("🎀 Productos destacados",21,dark,true); ft.setPadding(6,18,6,8); content.addView(ft); addProducts(0,6);
        Button create=btn("✨ CREA TU MOÑO CON TU NOMBRE Y ESTILO"); create.setTextColor(Color.WHITE); create.setBackground(rounded(pink,32)); create.setOnClickListener(v->showCreateBow()); content.addView(create,new LinearLayout.LayoutParams(-1,58));
    }

    void addProducts(int start,int count){
        for(int i=start;i<Math.min(productNames.length,start+count);i++){
            LinearLayout card=row(); card.setPadding(10,8,10,8); card.setBackground(rounded(Color.WHITE,30));
            ImageView im=new ImageView(this); im.setImageResource(productImages[i]); im.setScaleType(ImageView.ScaleType.CENTER_CROP); card.addView(im,new LinearLayout.LayoutParams(115,115));
            LinearLayout info=col(); info.setPadding(10,0,4,0); info.addView(text(productNames[i],17,dark,true)); info.addView(text(i==1||i==2?"$180":"Desde $100",16,pink,true)); info.addView(text("♡  Ver producto   🛒",13,dark,false)); card.addView(info,new LinearLayout.LayoutParams(0,-1,1)); content.addView(card,new LinearLayout.LayoutParams(-1,135)); Space sp=new Space(this); content.addView(sp,new LinearLayout.LayoutParams(1,8));
        }
    }

    void showCatalog(String category){ base(); content.addView(center(category,23,dark,true)); addProducts(0,10); }

    void showCreateBow(){ base(); content.addView(center("✨ Crea tu moño",24,dark,true)); content.addView(text("Elige el estilo, colores, nombre y decoración.",15,dark,false)); EditText name=new EditText(this); name.setHint("Nombre que llevará el moño"); name.setBackground(rounded(Color.WHITE,25)); content.addView(name); String[] opts={"Tipo de moño","Color 1","Color 2","Color 3","Estilo","Decoración"}; for(String o:opts){ Spinner s=new Spinner(this); String[] v={o,"Rosa","Lila","Blanco","Personalizado"}; s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,v)); content.addView(s,new LinearLayout.LayoutParams(-1,55)); } Button g=btn("✨ GENERAR MOÑO"); g.setBackground(rounded(pink,30)); g.setTextColor(Color.WHITE); g.setOnClickListener(v->{ content.addView(center("🎀 Vista previa",20,dark,true)); content.addView(center("Tu diseño quedará 🟡 EN PROCESO al solicitarlo.",14,dark,false)); Button r=btn("🛒 SOLICITAR ESTE MOÑO"); r.setOnClickListener(x->Toast.makeText(this,"Diseño enviado: EN PROCESO",Toast.LENGTH_LONG).show()); content.addView(r); }); content.addView(g); }
    void showOrders(){ base(); content.addView(center("📦 Mis pedidos",24,dark,true)); content.addView(text("🟡 En proceso\n🟢 Aceptado / Preparando\n🔵 Enviado\n🟣 Entregado\n🔴 Rechazado con motivo",16,dark,false)); }
    void showAccount(){ base(); content.addView(center("♡ Mi cuenta",24,dark,true)); for(String s:new String[]{"📦 Mis pedidos","🎀 Mis moños personalizados","📍 Mis direcciones","💳 Métodos de pago","🔔 Notificaciones","♡ Mis favoritos"})content.addView(btn(s)); }
}
