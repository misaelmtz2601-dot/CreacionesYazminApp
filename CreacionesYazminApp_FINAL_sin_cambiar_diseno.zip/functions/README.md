# Backend Mercado Pago — Creaciones Yazmin

El APK nunca contiene el Access Token. La app crea el pedido en Firestore y llama a `crearOrderMercadoPago`; la Cloud Function crea la Order de Mercado Pago y devuelve `checkoutUrl`.

## Secretos

Configurar en Firebase/Cloud Functions: `MP_ACCESS_TOKEN` (credencial privada de prueba durante desarrollo) y `MP_WEBHOOK_SECRET` (clave de Webhooks de Mercado Pago). Nunca guardar estos valores en GitHub ni en el APK.

## Despliegue

Requiere Firebase CLI y un proyecto Firebase con Cloud Functions habilitado.

```bash
firebase functions:secrets:set MP_ACCESS_TOKEN
firebase functions:secrets:set MP_WEBHOOK_SECRET
firebase deploy --only functions
```

Después, configurar en Mercado Pago Developers > Webhooks la URL HTTPS de `mercadoPagoWebhook` y activar el evento Order. Mercado Pago recomienda Webhooks y firma `x-signature` para validar el origen.


## Integración de pagos — desarrollo
- El Access Token de Mercado Pago debe permanecer únicamente en secretos del backend.
- La aplicación Android no debe contener credenciales privadas de producción.
- Antes de pasar a producción, probar creación de orden, pago aprobado, pago rechazado, webhook y reembolso.
- Mantener las credenciales de prueba durante el desarrollo.
