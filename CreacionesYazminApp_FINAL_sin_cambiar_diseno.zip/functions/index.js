const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();
const MP_ACCESS_TOKEN = defineSecret("MP_ACCESS_TOKEN");
const MP_WEBHOOK_SECRET = defineSecret("MP_WEBHOOK_SECRET");

exports.crearOrderMercadoPago = onCall(
  { region: "us-central1", secrets: [MP_ACCESS_TOKEN], cors: true },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Debes iniciar sesión.");
    const pedidoId = request.data?.pedidoId;
    if (!pedidoId || typeof pedidoId !== "string") throw new HttpsError("invalid-argument", "Falta el pedido.");

    const ref = db.collection("pedidos").doc(pedidoId);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpsError("not-found", "Pedido no encontrado.");
    const order = snap.data();
    if (order.usuarioId !== request.auth.uid) throw new HttpsError("permission-denied", "Pedido no pertenece al usuario.");
    if (!Array.isArray(order.productos) || order.productos.length === 0) throw new HttpsError("failed-precondition", "El pedido no tiene productos.");
    if (order.checkoutUrl && order.mercadoPagoOrderId) {
      return { orderId: order.mercadoPagoOrderId, checkoutUrl: order.checkoutUrl };
    }

    // Recalcular precios en servidor para no confiar en importes enviados por el teléfono.
    const items = [];
    let subtotal = 0;
    for (const it of order.productos) {
      const productId = String(it.productoId || "");
      const quantity = Math.max(1, Number(it.cantidad || 1));
      if (!productId) throw new HttpsError("invalid-argument", "Producto sin identificador.");
      const productSnap = await db.collection("productos").doc(productId).get();
      if (!productSnap.exists) throw new HttpsError("failed-precondition", "Un producto ya no existe.");
      const product = productSnap.data();
      if (product.disponible === false || product.activo === false) throw new HttpsError("failed-precondition", "Un producto ya no está disponible.");
      const unitPrice = Number(product.precio || 0);
      const lineTotal = unitPrice * quantity;
      subtotal += lineTotal;
      items.push({
        title: String(product.nombre || "Producto Creaciones Yazmin").slice(0, 200),
        unit_price: unitPrice.toFixed(2),
        quantity,
        unit_measure: "unit",
        total_amount: lineTotal.toFixed(2)
      });
    }

    const shipping = subtotal >= 1000 ? 0 : 100;
    if (shipping > 0) {
      items.push({
        title: "Envío Creaciones Yazmin",
        unit_price: shipping.toFixed(2),
        quantity: 1,
        unit_measure: "unit",
        total_amount: shipping.toFixed(2)
      });
    }
    const total = subtotal + shipping;
    await ref.update({ subtotal, envio: shipping, total, validadoServidor: true });

    const payload = {
      type: "online",
      processing_mode: "manual",
      total_amount: total.toFixed(2),
      external_reference: pedidoId,
      payer: { email: request.auth.token.email || "comprador@creacionesyazmin.test" },
      items,
      description: `Pedido Creaciones Yazmin ${pedidoId}`,
      config: {
        online: {
          success_url: `creacionesyazmin://payment/success?pedido=${encodeURIComponent(pedidoId)}`,
          failure_url: `creacionesyazmin://payment/failure?pedido=${encodeURIComponent(pedidoId)}`,
          pending_url: `creacionesyazmin://payment/pending?pedido=${encodeURIComponent(pedidoId)}`,
          auto_return: "all"
        }
      }
    };

    const response = await fetch("https://api.mercadopago.com/v1/orders", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": `Bearer ${MP_ACCESS_TOKEN.value()}`,
        "X-Idempotency-Key": `creaciones-yazmin-${pedidoId}`
      },
      body: JSON.stringify(payload)
    });
    const body = await response.json();
    if (!response.ok) {
      console.error("Mercado Pago create order error", response.status, body);
      throw new HttpsError("internal", "Mercado Pago no pudo crear la orden.");
    }

    await ref.update({
      mercadoPagoOrderId: body.id,
      checkoutUrl: body.checkout_url,
      estadoPago: "CHECKOUT_CREADO",
      mercadoPagoStatus: body.status || "created",
      fechaPagoActualizada: admin.firestore.FieldValue.serverTimestamp()
    });
    return { orderId: body.id, checkoutUrl: body.checkout_url };
  }
);

exports.mercadoPagoWebhook = onRequest(
  { region: "us-central1", secrets: [MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET], cors: true },
  async (req, res) => {
    if (req.method !== "POST") return res.status(405).send("Method Not Allowed");

    const dataId = req.query["data.id"];
    const type = req.query.type;
    const signature = req.get("x-signature");
    const requestId = req.get("x-request-id");
    const secret = MP_WEBHOOK_SECRET.value();

    if (secret && signature && requestId && dataId) {
      const parts = Object.fromEntries(signature.split(",").map(x => x.split("=")));
      const manifest = `id:${dataId};request-id:${requestId};ts:${parts.ts};`;
      const expected = crypto.createHmac("sha256", secret).update(manifest).digest("hex");
      const received = Buffer.from(parts.v1 || "", "utf8");
      const expectedBuf = Buffer.from(expected, "utf8");
      if (received.length !== expectedBuf.length || !crypto.timingSafeEqual(expectedBuf, received)) {
        return res.status(401).send("Invalid signature");
      }
    }

    res.status(200).send("OK");
    if (type !== "order" || !dataId) return;

    try {
      const mp = await fetch(`https://api.mercadopago.com/v1/orders/${encodeURIComponent(dataId)}`, {
        headers: { authorization: `Bearer ${MP_ACCESS_TOKEN.value()}` }
      });
      const order = await mp.json();
      if (!mp.ok) return;

      const q = await db.collection("pedidos").where("mercadoPagoOrderId", "==", String(dataId)).limit(1).get();
      if (q.empty) return;
      const ref = q.docs[0].ref;
      const update = {
        mercadoPagoStatus: order.status || null,
        totalPagado: Number(order.total_paid_amount || 0),
        fechaPagoActualizada: admin.firestore.FieldValue.serverTimestamp()
      };
      if (order.status === "processed") update.estadoPago = "APROBADO";
      else if (order.status === "action_required") update.estadoPago = "REQUIERE_ACCION";
      else if (order.status === "canceled" || order.status === "expired") update.estadoPago = "CANCELADO";
      await ref.update(update);
    } catch (e) {
      console.error("Webhook processing error", e);
    }
  }
);
